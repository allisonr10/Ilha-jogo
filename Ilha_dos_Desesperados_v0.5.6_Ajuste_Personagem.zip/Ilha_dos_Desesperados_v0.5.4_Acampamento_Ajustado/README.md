# Ilha dos Desesperados — Versão 0.4.1

## Requisitos
Godot 4.7.2 (Godot 4.x recente).

## Instalação
1. Extraia o ZIP em uma pasta nova.
2. Abra Godot > Importar.
3. Selecione `project.godot`.
4. Abra e execute com F5.

## Controles
- Clique em objetos para Daniel caminhar automaticamente e interagir.
- I: inventário.
- C: acampamento.
- J: diário.
- F5: salvar.
- ESC: fechar janelas.

## Novidades da versão 0.4
- Retratos ilustrados de Daniel e Henrique nos diálogos.
- Henrique desenhado no cenário, próximo ao acampamento.
- Daniel redesenhado com mais detalhes de roupa, mochila, rosto e caminhada.
- Praia enriquecida com abrigo de lona, rádio, fogueira, pedras, luz e vegetação em camadas.
- Inventário com ícones pixel art próprios para canivete, corda, pano, peça de rádio, comida e água.
- Seleção de item mais clara: a barra de ajuda indica o objeto em que o item pode ser usado.

## Sistemas preservados
- Hotspots da praia, destroços, caixa, pegadas, pedras, floresta, rádio e Henrique.
- Diálogos ramificados e escolhas.
- Inventário funcional e uso de itens em objetos.
- Recursos, necessidades, diário, acampamento e salvamento local.

## Observação
Esta versão melhora a apresentação e os assets de interface/personagens, mas ainda não é um tileset animado profissional. As artes são assets PNG pixelados e desenhos procedurais em Godot; o cenário completo com animações de água, sombras dinâmicas e spritesheets direcionais será desenvolvido nas próximas versões.


## Correção visual 0.4.1
- Daniel e Henrique agora usam imagens de personagem com transparência no cenário, em vez de serem desenhados por blocos geométricos no código.
- Daniel mantém um pequeno balanço durante o deslocamento.
- O ponto clicável de Henrique foi ajustado para acompanhar sua posição no cenário.
- Os retratos de diálogo e o restante da lógica da versão 0.4 foram preservados.

Observação: estes são sprites de pose única recortados do conceito visual. Ainda não são spritesheets com animação completa em quatro direções.


## Correção de composição da Praia
- Barraca, fogueira e rádio reposicionados para a faixa de areia central.
- Henrique recebe um sprite de cenário dedicado, extraído da pose em pé, e é desenhado ao lado da barraca.
- Hotspots de rádio e Henrique reposicionados para acompanhar os elementos visuais.


## Versão 0.5.4 — correção do acampamento
- Henrique agora usa um recorte de corpo inteiro extraído da pose em pé, com transparência.
- Barraca, fogueira, rádio e Henrique foram movidos para a faixa de areia central.
- Hotspots do rádio e de Henrique foram ajustados às novas posições.
