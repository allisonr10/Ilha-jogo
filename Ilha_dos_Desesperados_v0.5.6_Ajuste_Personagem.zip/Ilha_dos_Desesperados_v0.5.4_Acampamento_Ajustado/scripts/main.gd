extends Node2D

# Ilha dos Desesperados — Protótipo 0.5.4 — Acampamento ajustado
# Aventura gráfica point-and-click com caminhada automática.

const SAVE_PATH := "user://ilha_desesperados_v02.cfg"
const VIEW_SIZE := Vector2(960, 540)

var daniel_pos := Vector2(465, 365)
var daniel_target := daniel_pos
var daniel_speed := 185.0
var daniel_walking := false
var facing := 1
var frame := 0.0

var day := 1
var time_name := "MANHÃ"
var health := 100
var hunger := 82
var thirst := 78
var energy := 90
var sanity := 92
var wood := 0
var food := 1
var water := 1
var clues := 0
var inventory: Array[String] = ["Canivete"]
var flags := {
    "crate": false,
    "footprints": false,
    "radio": false,
    "henrique_met": false,
    "henrique_trust": false,
    "campfire": false,
    "night_event": false
}
var active_dialogue := false
var dialogue_title := ""
var dialogue_body := ""
var dialogue_choices: Array[Dictionary] = []
var current_hover := ""
var current_action := ""
var status_message := "Investigue os destroços. Talvez ainda exista algo útil."
var message_timer := 6.0
var ui: CanvasLayer
var scene_root: Control
var dialogue_panel: PanelContainer
var dialogue_name: Label
var dialogue_text: RichTextLabel
var dialogue_buttons: VBoxContainer
var dialogue_portrait: TextureRect
var hud_stats: Label
var inventory_label: Label
var status_label: Label
var cursor_label: Label
var time_label: Label
var camp_panel: PanelContainer
var camp_body: Label
var inventory_panel: PanelContainer
var inventory_list: VBoxContainer
var inventory_hint: Label
var selected_item := ""
var rng := RandomNumberGenerator.new()
var daniel_sprite_texture: Texture2D
var henrique_sprite_texture: Texture2D
var daniel_frames: Dictionary = {}
var henrique_frames: Dictionary = {}
var scene_background: Texture2D
var object_textures: Dictionary = {}
var facing_direction := "sul"

# Hotspots: rects are in 960x540 logical coordinates.
var hotspots := [
    {"id":"wreck","label":"Destroços do navio","rect":Rect2(40,245,190,125),"target":Vector2(205,365),"desc":"Madeiras partidas e partes do casco foram lançadas na areia."},
    {"id":"crate","label":"Caixa de suprimentos","rect":Rect2(265,330,78,66),"target":Vector2(300,395),"desc":"Uma caixa quase intacta está presa entre as tábuas."},
    # Henrique vem antes das pegadas na lista e tem uma área de clique ajustada ao sprite.
    {"id":"henrique","label":"Henrique","rect":Rect2(396,300,58,70),"target":Vector2(455,370),"desc":"Um homem observa você junto ao acampamento."},
    # Pegadas transferidas para um trecho livre de areia, sem cobrir a barraca ou Henrique.
    {"id":"footprints","label":"Pegadas na areia","rect":Rect2(535,265,105,55),"target":Vector2(585,345),"desc":"Pegadas recentes seguem em direção à vegetação."},
    {"id":"shore","label":"Maré e pedras","rect":Rect2(0,380,180,120),"target":Vector2(155,425),"desc":"Entre as pedras, algo reflete a luz."},
    {"id":"jungle","label":"Entrada da floresta","rect":Rect2(700,110,220,180),"target":Vector2(745,285),"desc":"A vegetação é densa. Há uma trilha estreita entre as árvores."},
    {"id":"radio","label":"Rádio danificado","rect":Rect2(475,315,65,60),"target":Vector2(455,380),"desc":"Um rádio de emergência está coberto de areia."}
]

func _ready() -> void:
    rng.randomize()
    _load_clean_assets()
    _build_ui()
    _load_game()
    queue_redraw()
    _set_status("Você acordou na Praia dos Destroços. Investigue os arredores.")

func _process(delta: float) -> void:
    if daniel_walking and not active_dialogue and not camp_panel.visible:
        var diff := daniel_target - daniel_pos
        if diff.length() <= daniel_speed * delta:
            daniel_pos = daniel_target
            daniel_walking = false
            if selected_item != "":
                _use_item_on(current_action)
            else:
                _perform_action(current_action)
        else:
            daniel_pos += diff.normalized() * daniel_speed * delta
            facing = 1 if diff.x >= 0 else -1
            if abs(diff.x) > abs(diff.y):
                facing_direction = "leste" if diff.x > 0 else "oeste"
            else:
                facing_direction = "sul" if diff.y > 0 else "norte"
            frame += delta * 9.0
    if message_timer > 0:
        message_timer -= delta
        if message_timer <= 0:
            status_label.text = ""
    _update_hotspot_hover()
    queue_redraw()

func _input(event: InputEvent) -> void:
    if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
        var pos := get_global_mouse_position()
        if active_dialogue or camp_panel.visible or inventory_panel.visible:
            return
        _click_world(pos)
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_ESCAPE:
            _close_dialogue()
            camp_panel.visible = false
            _close_inventory()
        elif event.keycode == KEY_I and not active_dialogue:
            _show_inventory()
        elif event.keycode == KEY_C and not active_dialogue:
            _open_camp()
        elif event.keycode == KEY_J and not active_dialogue:
            _show_journal()
        elif event.keycode == KEY_F5:
            _save_game()

func _build_ui() -> void:
    ui = CanvasLayer.new()
    add_child(ui)
    scene_root = Control.new()
    scene_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    scene_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
    ui.add_child(scene_root)

    var hud := PanelContainer.new()
    hud.position = Vector2(14,12)
    hud.custom_minimum_size = Vector2(300,82)
    _style_panel(hud, Color("#17272b"), 0.92)
    scene_root.add_child(hud)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation",3)
    hud.add_child(v)
    var title := Label.new()
    title.text = "DANIEL  •  DIA %02d" % day
    title.add_theme_color_override("font_color",Color("#f2c36e"))
    title.add_theme_font_size_override("font_size",17)
    v.add_child(title)
    hud_stats = Label.new()
    hud_stats.add_theme_color_override("font_color",Color("#f6f0dc"))
    hud_stats.add_theme_font_size_override("font_size",12)
    v.add_child(hud_stats)

    var time_panel := PanelContainer.new()
    time_panel.anchor_left=1
    time_panel.anchor_right=1
    time_panel.offset_left=-166
    time_panel.offset_right=-14
    time_panel.offset_top=14
    time_panel.offset_bottom=55
    _style_panel(time_panel,Color("#17272b"),0.94)
    scene_root.add_child(time_panel)
    time_label=Label.new()
    time_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    time_label.text="☀ DIA  •  %s" % time_name
    time_label.add_theme_color_override("font_color",Color("#f2c36e"))
    time_panel.add_child(time_label)

    var bottom := PanelContainer.new()
    bottom.anchor_left=0
    bottom.anchor_right=1
    bottom.anchor_top=1
    bottom.anchor_bottom=1
    bottom.offset_left=14
    bottom.offset_right=-14
    bottom.offset_top=-58
    bottom.offset_bottom=-12
    _style_panel(bottom,Color("#17272b"),0.95)
    scene_root.add_child(bottom)
    var row := HBoxContainer.new()
    row.add_theme_constant_override("separation",12)
    bottom.add_child(row)
    inventory_label=Label.new()
    inventory_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL
    inventory_label.add_theme_color_override("font_color",Color("#f6f0dc"))
    inventory_label.add_theme_font_size_override("font_size",13)
    row.add_child(inventory_label)
    _add_small_button(row,"I  INVENTÁRIO",_show_inventory)
    _add_small_button(row,"C  ACAMPAMENTO",_open_camp)
    _add_small_button(row,"J  DIÁRIO",_show_journal)
    _add_small_button(row,"SALVAR",_save_game)

    status_label=Label.new()
    status_label.position=Vector2(20,105)
    status_label.add_theme_color_override("font_color",Color("#fff0c8"))
    status_label.add_theme_font_size_override("font_size",15)
    scene_root.add_child(status_label)

    cursor_label=Label.new()
    cursor_label.anchor_left=0.5
    cursor_label.anchor_right=0.5
    cursor_label.anchor_top=1
    cursor_label.anchor_bottom=1
    cursor_label.offset_left=-180
    cursor_label.offset_right=180
    cursor_label.offset_top=-91
    cursor_label.offset_bottom=-65
    cursor_label.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    cursor_label.add_theme_color_override("font_color",Color("#ffe3a0"))
    scene_root.add_child(cursor_label)

    dialogue_panel=PanelContainer.new()
    dialogue_panel.visible=false
    dialogue_panel.anchor_left=0.5
    dialogue_panel.anchor_right=0.5
    dialogue_panel.anchor_top=1
    dialogue_panel.anchor_bottom=1
    dialogue_panel.offset_left=-390
    dialogue_panel.offset_right=390
    dialogue_panel.offset_top=-270
    dialogue_panel.offset_bottom=-76
    _style_panel(dialogue_panel,Color("#17272b"),0.98)
    scene_root.add_child(dialogue_panel)
    var dialogue_row := HBoxContainer.new()
    dialogue_row.add_theme_constant_override("separation", 12)
    dialogue_panel.add_child(dialogue_row)
    dialogue_portrait = TextureRect.new()
    dialogue_portrait.custom_minimum_size = Vector2(104, 112)
    dialogue_portrait.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    dialogue_portrait.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
    dialogue_portrait.texture = load("res://assets/portraits/daniel.png")
    dialogue_row.add_child(dialogue_portrait)
    var dv:=VBoxContainer.new()
    dv.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    dv.add_theme_constant_override("separation",7)
    dialogue_row.add_child(dv)
    dialogue_name=Label.new()
    dialogue_name.add_theme_color_override("font_color",Color("#f2c36e"))
    dialogue_name.add_theme_font_size_override("font_size",19)
    dv.add_child(dialogue_name)
    dialogue_text=RichTextLabel.new()
    dialogue_text.fit_content=true
    dialogue_text.scroll_active=false
    dialogue_text.custom_minimum_size=Vector2(0,66)
    dialogue_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    dialogue_text.add_theme_color_override("default_color",Color("#f6f0dc"))
    dv.add_child(dialogue_text)
    dialogue_buttons=VBoxContainer.new()
    dialogue_buttons.add_theme_constant_override("separation",4)
    dv.add_child(dialogue_buttons)

    camp_panel=PanelContainer.new()
    camp_panel.visible=false
    camp_panel.anchor_left=0.5
    camp_panel.anchor_right=0.5
    camp_panel.anchor_top=0.5
    camp_panel.anchor_bottom=0.5
    camp_panel.offset_left=-240
    camp_panel.offset_right=240
    camp_panel.offset_top=-190
    camp_panel.offset_bottom=190
    _style_panel(camp_panel,Color("#17272b"),0.98)
    scene_root.add_child(camp_panel)
    var cv:=VBoxContainer.new()
    cv.add_theme_constant_override("separation",9)
    camp_panel.add_child(cv)
    var ct:=Label.new()
    ct.text="ACAMPAMENTO IMPROVISADO"
    ct.add_theme_color_override("font_color",Color("#f2c36e"))
    ct.add_theme_font_size_override("font_size",20)
    cv.add_child(ct)
    camp_body=Label.new()
    camp_body.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
    camp_body.add_theme_color_override("font_color",Color("#f6f0dc"))
    cv.add_child(camp_body)
    _add_small_button(cv,"Construir abrigo (3 madeira)",_build_shelter)
    _add_small_button(cv,"Comer e beber",_eat_drink)
    _add_small_button(cv,"Descansar",_rest)
    _add_small_button(cv,"Encerrar o dia",_end_day)
    _add_small_button(cv,"Fechar",func(): camp_panel.visible=false)

    inventory_panel = PanelContainer.new()
    inventory_panel.visible = false
    inventory_panel.anchor_left = 0.5
    inventory_panel.anchor_right = 0.5
    inventory_panel.anchor_top = 0.5
    inventory_panel.anchor_bottom = 0.5
    inventory_panel.offset_left = -260
    inventory_panel.offset_right = 260
    inventory_panel.offset_top = -210
    inventory_panel.offset_bottom = 210
    _style_panel(inventory_panel, Color("#17272b"), 0.98)
    scene_root.add_child(inventory_panel)
    var iv := VBoxContainer.new()
    iv.add_theme_constant_override("separation", 8)
    inventory_panel.add_child(iv)
    var inventory_title := Label.new()
    inventory_title.text = "MOCHILA DE DANIEL"
    inventory_title.add_theme_color_override("font_color", Color("#f2c36e"))
    inventory_title.add_theme_font_size_override("font_size", 21)
    iv.add_child(inventory_title)
    inventory_hint = Label.new()
    inventory_hint.text = "Selecione um item para ver detalhes."
    inventory_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    inventory_hint.add_theme_color_override("font_color", Color("#f6f0dc"))
    iv.add_child(inventory_hint)
    var inventory_scroll := ScrollContainer.new()
    inventory_scroll.custom_minimum_size = Vector2(0, 230)
    inventory_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
    iv.add_child(inventory_scroll)
    inventory_list = VBoxContainer.new()
    inventory_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    inventory_scroll.add_child(inventory_list)
    _add_small_button(iv, "Fechar mochila", _close_inventory)

    _update_hud()

func _add_small_button(parent: Node, text_value: String, callback: Callable) -> void:
    var b:=Button.new()
    b.text=text_value
    b.pressed.connect(callback)
    b.add_theme_font_size_override("font_size",12)
    parent.add_child(b)

func _style_panel(p: PanelContainer, color: Color, alpha: float) -> void:
    var st:=StyleBoxFlat.new()
    st.bg_color=color
    st.bg_color.a=alpha
    st.border_color=Color("#b58a50")
    st.set_border_width_all(2)
    st.set_corner_radius_all(7)
    st.set_content_margin_all(9)
    p.add_theme_stylebox_override("panel",st)

func _click_world(pos: Vector2) -> void:
    # Ignore clicks on HUD / inventory strip.
    if pos.y < 95 or pos.y > 465:
        return
    for h in hotspots:
        var hotspot_rect: Rect2 = h["rect"]
        if hotspot_rect.has_point(pos):
            daniel_target=h["target"]
            current_action=str(h.id)
            daniel_walking=daniel_pos.distance_to(daniel_target)>8
            if not daniel_walking:
                if selected_item != "":
                    _use_item_on(current_action)
                else:
                    _perform_action(current_action)
            return
    # Clicking open ground makes Daniel walk there.
    daniel_target=Vector2(clampf(pos.x,30,930),clampf(pos.y,135,450))
    current_action="walk"
    daniel_walking=daniel_pos.distance_to(daniel_target)>8

func _perform_action(action: String) -> void:
    match action:
        "wreck":
            _show_dialogue("DESTROÇOS", "O casco foi partido contra as rochas. Há marcas de ferramentas nas tábuas, como se alguém tivesse desmontado parte do navio depois do naufrágio.", [{"text":"Examinar as tábuas","action":"wreck_wood"},{"text":"Voltar","action":"close"}])
        "crate":
            if not bool(flags.crate):
                _show_dialogue("CAIXA DE SUPRIMENTOS", "A tampa está emperrada. Com esforço, Daniel consegue abrir a caixa e encontra materiais que ainda podem ser aproveitados.", [{"text":"Recolher 3 madeiras e 2 comidas","action":"take_crate"},{"text":"Deixar para depois","action":"close"}])
            else:
                _show_dialogue("CAIXA VAZIA", "A caixa já foi vasculhada.", [{"text":"Voltar","action":"close"}])
        "footprints":
            if not bool(flags.footprints):
                _show_dialogue("PEGADAS NA AREIA", "As pegadas são recentes. Uma delas termina abruptamente na linha da água. Não parecem ser de alguém que saiu caminhando.", [{"text":"Registrar no diário","action":"record_footprints"},{"text":"Seguir a trilha com os olhos","action":"close"}])
            else:
                _show_dialogue("PEGADAS", "Você já registrou as pegadas. Elas seguem em direção à floresta.", [{"text":"Voltar","action":"close"}])
        "shore":
            _show_dialogue("ENTRE AS PEDRAS", "Um pequeno brilho aparece entre as pedras. É uma peça metálica de rádio, ainda em bom estado.", [{"text":"Guardar a peça","action":"take_radio_part"},{"text":"Deixar onde está","action":"close"}])
        "jungle":
            _show_dialogue("ENTRADA DA FLORESTA", "A trilha desaparece poucos metros adiante. O interior da ilha parece mais escuro do que deveria para esta hora.", [{"text":"Entrar na floresta (em breve)","action":"close"},{"text":"Voltar à praia","action":"close"}])
        "radio":
            if not bool(flags.radio):
                _show_dialogue("RÁDIO DANIFICADO", "O rádio ainda tem energia, mas falta uma peça. Quando você encosta no aparelho, uma voz atravessa a estática: “Estação Ícaro... protocolo de contenção...”", [{"text":"Anotar a transmissão","action":"record_radio"},{"text":"Afastar-se","action":"close"}])
            else:
                _show_dialogue("RÁDIO", "A frequência está silenciosa. O nome Ícaro ficou anotado no diário.", [{"text":"Voltar","action":"close"}])
        "henrique":
            if not bool(flags.henrique_met):
                _show_dialogue("HENRIQUE", "“Não se aproxime mais. Você veio do navio? Não devia ter chegado até aqui.”\n\nO homem parece assustado, mas segura uma ferramenta como se fosse uma arma.", [{"text":"“Só quero ajuda. Não sou uma ameaça.”","action":"henrique_trust"},{"text":"“O que você sabe sobre esta ilha?”","action":"henrique_question"},{"text":"“Afaste-se. Não vou obedecer.”","action":"henrique_hostile"}])
            else:
                _show_dialogue("HENRIQUE", "“Eu já disse para não ficar perto da floresta depois do pôr do sol.”", [{"text":"Perguntar sobre Ícaro","action":"henrique_icarus"},{"text":"Encerrar conversa","action":"close"}])
        "walk":
            pass

func _show_dialogue(title: String, body: String, choices: Array[Dictionary]) -> void:
    active_dialogue=true
    dialogue_panel.visible=true
    dialogue_name.text=title
    dialogue_text.text=body
    if title.to_upper().contains("HENRIQUE"):
        dialogue_portrait.texture = load("res://assets/portraits/henrique.png")
    else:
        dialogue_portrait.texture = load("res://assets/portraits/daniel.png")
    for c in dialogue_buttons.get_children():
        c.queue_free()
    for choice in choices:
        var b:=Button.new()
        b.text=str(choice.text)
        b.pressed.connect(_choose.bind(str(choice.action)))
        dialogue_buttons.add_child(b)

func _choose(action: String) -> void:
    match action:
        "take_crate":
            flags.crate=true
            wood+=3
            food+=2
            if not inventory.has("Corda"):
                inventory.append("Corda")
            if not inventory.has("Pano limpo"):
                inventory.append("Pano limpo")
            _set_status("Você recolheu madeira, comida, uma corda e pano limpo.")
            _close_dialogue()
        "record_footprints":
            flags.footprints=true
            clues+=1
            _set_status("Pegadas registradas no diário. Nova pista descoberta.")
            _close_dialogue()
        "take_radio_part":
            if not inventory.has("Peça de rádio"):
                inventory.append("Peça de rádio")
                _set_status("Peça de rádio adicionada ao inventário.")
            _close_dialogue()
        "record_radio":
            flags.radio=true
            clues+=1
            _set_status("Nova pista: Estação Ícaro — protocolo de contenção.")
            _close_dialogue()
        "henrique_trust":
            flags.henrique_met=true
            flags.henrique_trust=true
            _show_dialogue("HENRIQUE", "“Talvez eu tenha julgado você cedo demais. Meu nome é Henrique. Há um abrigo antigo perto do riacho. Mas não vá para a floresta depois do pôr do sol.”", [{"text":"“Por que não?”","action":"henrique_why"},{"text":"Agradecer e encerrar","action":"close"}])
        "henrique_question":
            flags.henrique_met=true
            clues+=1
            _show_dialogue("HENRIQUE", "“Ícaro... Não repita esse nome tão alto. Procure a torre de rádio, mas não confie em qualquer voz que ouvir.”", [{"text":"“O que aconteceu aqui?”","action":"henrique_icarus"},{"text":"Encerrar conversa","action":"close"}])
        "henrique_hostile":
            flags.henrique_met=true
            flags.henrique_trust=false
            _show_dialogue("HENRIQUE", "“Então fique longe de mim.” Ele recua e desaparece entre as árvores. Você sente que perdeu uma oportunidade.", [{"text":"Deixar a área","action":"close"}])
        "henrique_why":
            clues+=1
            _show_dialogue("HENRIQUE", "“Porque às vezes a floresta responde quando alguém chama. E nem sempre é uma pessoa.”", [{"text":"Encerrar conversa","action":"close"}])
        "henrique_icarus":
            clues+=1
            _show_dialogue("HENRIQUE", "“Havia uma estação de pesquisa. O pessoal chamava de Ícaro. Um dia, as luzes apagaram. Na manhã seguinte, ninguém admitia que ela existia.”", [{"text":"Guardar a informação","action":"close"}])
        "night_investigate":
            clues+=1
            sanity=maxi(0,sanity-5)
            _show_dialogue("PEGADAS AO LADO DA CAMA", "As pegadas começam junto à sua cama e seguem até a árvore mais próxima. Do outro lado do tronco, uma voz sussurra seu nome — com a sua própria voz.", [{"text":"Voltar para o abrigo","action":"close"}])
        "wreck_wood":
            wood+=1
            _show_dialogue("DESTROÇOS", "Você consegue retirar uma tábua aproveitável. (+1 madeira)", [{"text":"Continuar","action":"close"}])
        "close":
            _close_dialogue()
        _:
            _close_dialogue()
    _update_hud()
    _save_quietly()

func _close_dialogue() -> void:
    active_dialogue=false
    dialogue_panel.visible=false

func _update_hotspot_hover() -> void:
    if active_dialogue or camp_panel.visible:
        cursor_label.text=""
        return
    var p:=get_global_mouse_position()
    var label:=""
    for h in hotspots:
        var hotspot_rect: Rect2 = h["rect"]
        if hotspot_rect.has_point(p):
            label=str(h["label"])
            break
    if selected_item != "":
        cursor_label.text = ("✦ Usar %s em: %s" % [selected_item, label]) if label != "" else ("✦ %s selecionado — clique em um objeto" % selected_item)
    else:
        cursor_label.text=("◉  "+label+"  •  clique para investigar") if label!="" else "Clique em um local para caminhar"

func _open_camp() -> void:
    camp_panel.visible=true
    camp_body.text="Dia %d — %s\n\nVida: %d%%     Fome: %d%%     Sede: %d%%\nEnergia: %d%%     Sanidade: %d%%\n\nÁgua: %d   Comida: %d   Madeira: %d\n\nAbrigo: improvisado\n\nA praia é vulnerável. Reúna madeira para construir uma proteção." % [day,time_name,health,hunger,thirst,energy,sanity,water,food,wood]

func _build_shelter() -> void:
    if wood<3:
        _set_status("Você precisa de 3 madeiras para melhorar o abrigo.")
    else:
        wood-=3
        energy=maxi(0,energy-8)
        _set_status("Você reforçou o abrigo com madeira.")
    camp_panel.visible=false
    _update_hud()

func _eat_drink() -> void:
    if food>0:
        food-=1
        hunger=mini(100,hunger+28)
    if water>0:
        water-=1
        thirst=mini(100,thirst+35)
    _set_status("Você conseguiu se alimentar e beber um pouco.")
    camp_panel.visible=false
    _update_hud()

func _rest() -> void:
    energy=mini(100,energy+25)
    _set_status("Daniel descansou. O tempo avançou.")
    _advance_time()
    camp_panel.visible=false
    _update_hud()

func _end_day() -> void:
    hunger=maxi(0,hunger-16)
    thirst=maxi(0,thirst-20)
    if hunger==0: health=maxi(0,health-7)
    if thirst==0: health=maxi(0,health-11)
    energy=mini(100,energy+12)
    day+=1
    time_name="MANHÃ"
    camp_panel.visible=false
    if not bool(flags.night_event):
        flags.night_event=true
        sanity=maxi(0,sanity-6)
        _show_dialogue("TRÊS BATIDAS", "Na primeira noite, três batidas soam do lado de fora do abrigo. Quando Daniel olha pela fresta, não há ninguém. Na areia, porém, existem pegadas que começam junto à sua cama.", [{"text":"Trancar a porta e esperar amanhecer","action":"close"},{"text":"Sair e investigar","action":"night_investigate"}])
    else:
        _set_status("Amanheceu. A ilha continua em silêncio.")
    _update_hud()
    _save_quietly()

func _advance_time() -> void:
    if time_name=="MANHÃ": time_name="TARDE"
    elif time_name=="TARDE": time_name="NOITE"
    else: _end_day()
    time_label.text="☀ DIA  •  %s" % time_name

func _show_inventory() -> void:
    if active_dialogue or camp_panel.visible:
        return
    selected_item = ""
    inventory_hint.text = "Selecione um item para ver sua descrição e escolher como usá-lo."
    for child in inventory_list.get_children():
        child.queue_free()
    if inventory.is_empty():
        inventory_list.add_child(_inventory_label("A mochila está vazia."))
    else:
        for item in inventory:
            var item_row := HBoxContainer.new()
            item_row.add_theme_constant_override("separation", 8)
            inventory_list.add_child(item_row)
            var item_icon := TextureRect.new()
            item_icon.custom_minimum_size = Vector2(42, 42)
            item_icon.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
            item_icon.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
            item_icon.texture = _get_item_texture(str(item))
            item_row.add_child(item_icon)
            var item_button := Button.new()
            item_button.text = str(item)
            item_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
            item_button.custom_minimum_size = Vector2(0, 42)
            item_button.pressed.connect(_select_inventory_item.bind(str(item)))
            item_row.add_child(item_button)
    var supplies := _inventory_label("Recursos: %d madeira  •  %d comida  •  %d água" % [wood, food, water])
    inventory_list.add_child(supplies)
    inventory_panel.visible = true


func _get_item_texture(item: String) -> Texture2D:
    var paths := {
        "Canivete": "res://assets/items/canivete.png",
        "Corda": "res://assets/items/corda.png",
        "Pano limpo": "res://assets/items/pano.png",
        "Peça de rádio": "res://assets/items/radio_part.png",
        "Comida enlatada": "res://assets/items/comida.png",
        "Água": "res://assets/items/agua.png"
    }
    var path: String = paths.get(item, "")
    if path != "" and ResourceLoader.exists(path):
        return load(path) as Texture2D
    return null

func _inventory_label(value: String) -> Label:
    var label := Label.new()
    label.text = value
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    label.add_theme_color_override("font_color", Color("#f6f0dc"))
    return label


func _select_inventory_item(item: String) -> void:
    selected_item = item
    var descriptions := {
        "Canivete": "Ferramenta pequena. Pode cortar cordas e abrir materiais presos.",
        "Peça de rádio": "Componente encontrado na praia. Talvez sirva para reparar o rádio.",
        "Corda": "Pode ajudar a alcançar lugares difíceis ou prender objetos.",
        "Pano limpo": "Tecido aproveitável. Pode servir para improvisar um curativo."
    }
    inventory_hint.text = str(descriptions.get(item, "Item útil para exploração.")) + "\\n\\nSelecionado: " + item + ". Feche a mochila e clique em um objeto do cenário para tentar usá-lo."
    _set_status("Selecionado: %s. Clique em um objeto para tentar usar." % item)


func _close_inventory() -> void:
    if inventory_panel != null:
        inventory_panel.visible = false


func _use_item_on(target: String) -> void:
    var item := selected_item
    selected_item = ""
    _close_inventory()
    if item == "Canivete" and target == "crate":
        if not bool(flags.crate):
            _show_dialogue("CANIVETE", "Daniel encaixa a lâmina na fresta e força a tampa. A caixa se abre sem destruir as tábuas.", [{"text":"Recolher os suprimentos","action":"take_crate"},{"text":"Deixar para depois","action":"close"}])
        else:
            _show_dialogue("CAIXA", "A caixa já está vazia.", [{"text":"Continuar","action":"close"}])
    elif item == "Peça de rádio" and target == "radio":
        _show_dialogue("RÁDIO", "A peça parece encaixar no compartimento lateral. O rádio chia, mas ainda não consegue transmitir.", [{"text":"Anotar a transmissão","action":"record_radio"},{"text":"Guardar a peça","action":"close"}])
    elif item == "Corda" and target == "jungle":
        _show_dialogue("TRILHA DA FLORESTA", "Daniel prende a corda em uma raiz firme. Ela poderá ajudar na passagem por este trecho.", [{"text":"Continuar","action":"close"}])
    elif item == "Pano limpo" and target == "henrique":
        _show_dialogue("HENRIQUE", "Henrique observa o pano. “Guarde isso. Talvez você precise mais do que eu.”", [{"text":"Continuar","action":"close"}])
    else:
        _show_dialogue("NÃO FUNCIONOU", "Daniel não encontrou uma maneira útil de usar %s aqui." % item.to_lower(), [{"text":"Entendi","action":"close"}])
    _update_hud()
    _save_quietly()


func _show_journal() -> void:
    var text_value:="PISTAS DESCOBERTAS: %d\n\n" % clues
    if bool(flags.footprints): text_value+="• Pegadas recentes na praia.\n"
    if bool(flags.radio): text_value+="• Transmissão: Estação Ícaro / protocolo de contenção.\n"
    if bool(flags.henrique_met): text_value+="• Henrique conhece a antiga estação de pesquisa.\n"
    if clues==0: text_value+="Ainda não há pistas registradas. Investigue os arredores."
    _show_dialogue("DIÁRIO DE DANIEL",text_value,[{"text":"Fechar","action":"close"}])

func _set_status(text_value: String) -> void:
    status_label.text=text_value
    message_timer=5.0

func _update_hud() -> void:
    if hud_stats==null: return
    hud_stats.text="♥ %d   Fome %d   Sede %d   Energia %d   Sanidade %d" % [health,hunger,thirst,energy,sanity]
    inventory_label.text="🎒 %d itens   ✦ %d madeira   ✦ %d comida   ✦ %d água   ✦ %d pistas" % [inventory.size(),wood,food,water,clues]
    time_label.text="☀ DIA %d  •  %s" % [day,time_name]

func _save_quietly() -> void:
    var cfg:=ConfigFile.new()
    cfg.set_value("run","day",day)
    cfg.set_value("run","health",health)
    cfg.set_value("run","hunger",hunger)
    cfg.set_value("run","thirst",thirst)
    cfg.set_value("run","energy",energy)
    cfg.set_value("run","sanity",sanity)
    cfg.set_value("run","wood",wood)
    cfg.set_value("run","food",food)
    cfg.set_value("run","water",water)
    cfg.set_value("run","clues",clues)
    cfg.set_value("run","inventory",inventory)
    cfg.set_value("run","flags",flags)
    cfg.set_value("run","daniel_x",daniel_pos.x)
    cfg.set_value("run","daniel_y",daniel_pos.y)
    cfg.save(SAVE_PATH)

func _save_game() -> void:
    _save_quietly()
    _show_dialogue("CAMPANHA SALVA","Seu progresso foi salvo neste dispositivo.",[{"text":"Continuar","action":"close"}])

func _load_game() -> void:
    var cfg:=ConfigFile.new()
    if cfg.load(SAVE_PATH)!=OK: return
    day=int(cfg.get_value("run","day",day))
    health=int(cfg.get_value("run","health",health))
    hunger=int(cfg.get_value("run","hunger",hunger))
    thirst=int(cfg.get_value("run","thirst",thirst))
    energy=int(cfg.get_value("run","energy",energy))
    sanity=int(cfg.get_value("run","sanity",sanity))
    wood=int(cfg.get_value("run","wood",wood))
    food=int(cfg.get_value("run","food",food))
    water=int(cfg.get_value("run","water",water))
    clues=int(cfg.get_value("run","clues",clues))
    inventory=cfg.get_value("run","inventory",inventory)
    flags=cfg.get_value("run","flags",flags)
    daniel_pos=Vector2(float(cfg.get_value("run","daniel_x",daniel_pos.x)),float(cfg.get_value("run","daniel_y",daniel_pos.y)))
    daniel_target=daniel_pos
    _update_hud()

func _draw() -> void:
    # Fundo ilustrado da Praia dos Destroços.
    if scene_background != null:
        draw_texture_rect(scene_background, Rect2(0, 0, 960, 540), false)
    else:
        draw_rect(Rect2(0, 0, 960, 540), Color("#d9bd82"))

    # Destroços e caixa permanecem no setor esquerdo da faixa de areia.
    _draw_object("destrocos", Rect2(45, 285, 175, 105))
    _draw_object("caixa_fechada", Rect2(285, 355, 68, 58))

    # Acampamento reposicionado para a área de areia mais larga, longe da água.
    _draw_object("barraca", Rect2(335, 235, 142, 112))
    _draw_object("radio", Rect2(475, 315, 58, 52))
    _draw_object("pedras", Rect2(470, 360, 38, 23))
    _draw_object("fogueira", Rect2(485, 355, 48, 42))
    _draw_object("tronco", Rect2(535, 365, 50, 20))

    # Pegadas visíveis na areia, em área livre à direita do acampamento.
    _draw_footprints(Vector2(650, 300))

    # Henrique aparece em corpo inteiro, à frente da barraca, sobre a areia.
    _draw_henrique(Vector2(425, 365))
    _draw_daniel(daniel_pos)

    if current_hover != "":
        for h in hotspots:
            if str(h.id) == current_hover:
                draw_rect(h.rect, Color(1, 0.82, 0.38, 0.12), false, 2.0)
                break


func _draw_footprints(origin: Vector2) -> void:
    # Pequenas marcas alternadas, em tom discreto para parecerem impressas na areia.
    var footprint_color := Color("#8b704d")
    var pairs := [
        Vector2(0, 0), Vector2(13, 12),
        Vector2(26, 24), Vector2(39, 36),
        Vector2(52, 48)
    ]
    for i in range(pairs.size()):
        var offset: Vector2 = pairs[i]
        var side := -1.0 if i % 2 == 0 else 1.0
        draw_rect(Rect2(origin + offset + Vector2(side * 3.0, 0), Vector2(5, 8)), footprint_color)
        draw_rect(Rect2(origin + offset + Vector2(side * 4.0, -3), Vector2(3, 3)), footprint_color.lightened(0.12))


func _draw_palm(p: Vector2, scale_value: float) -> void:
    draw_line(p,p+Vector2(0,58*scale_value),Color("#76543a"),6*scale_value)
    var top:=p
    for angle in [-2.8,-2.1,-1.3,-0.5,0.4,1.2,2.0,2.8]:
        var end:=top+Vector2(cos(angle)*45*scale_value,sin(angle)*27*scale_value-9)
        draw_line(top,end,Color("#285b3c"),5*scale_value)
        draw_line(top,end+Vector2(0,4),Color("#4a8a4e"),2*scale_value)
    draw_rect(Rect2(p.x-4,p.y-5,8,8),Color("#8c683d"))

func _load_clean_assets() -> void:
    var directions := ["sul", "norte", "oeste", "leste"]
    for direction in directions:
        daniel_frames[direction] = []
        henrique_frames[direction] = []
        for frame_index in range(1, 5):
            var daniel_path := "res://assets/characters/daniel/walk/%s_%d.png" % [direction, frame_index]
            var henrique_path := "res://assets/characters/henrique/walk/%s_%d.png" % [direction, frame_index]
            if ResourceLoader.exists(daniel_path):
                daniel_frames[direction].append(load(daniel_path))
            if ResourceLoader.exists(henrique_path):
                henrique_frames[direction].append(load(henrique_path))

    # Use a real front-facing frame as the idle sprite; otherwise Daniel only shows his shadow.
    if daniel_frames.has("sul") and not daniel_frames["sul"].is_empty():
        daniel_sprite_texture = daniel_frames["sul"][0]
    var henrique_scene_path := "res://assets/characters/henrique/henrique_cenario.png"
    if ResourceLoader.exists(henrique_scene_path):
        henrique_sprite_texture = load(henrique_scene_path)
    elif henrique_frames.has("sul") and not henrique_frames["sul"].is_empty():
        henrique_sprite_texture = henrique_frames["sul"][0]

    var background_path := "res://assets/backgrounds/praia_dos_destrocos_v05.png"
    if ResourceLoader.exists(background_path):
        scene_background = load(background_path)

    var props := {
        "destrocos": "res://assets/objects/destrocos.png",
        "caixa_fechada": "res://assets/objects/caixa_fechada.png",
        "barraca": "res://assets/objects/barraca.png",
        "radio": "res://assets/objects/radio.png",
        "fogueira": "res://assets/objects/fogueira.png",
        "pedras": "res://assets/objects/pedras.png",
        "tronco": "res://assets/objects/tronco.png"
    }
    for prop_name in props:
        if ResourceLoader.exists(props[prop_name]):
            object_textures[prop_name] = load(props[prop_name])


func _draw_object(object_name: String, destination: Rect2) -> void:
    if object_textures.has(object_name):
        draw_texture_rect(object_textures[object_name], destination, false)


func _draw_daniel(p: Vector2) -> void:
    var frames_for_direction: Array = daniel_frames.get(facing_direction, [])
    var sprite: Texture2D = daniel_sprite_texture
    if not frames_for_direction.is_empty():
        if daniel_walking:
            sprite = frames_for_direction[int(frame) % frames_for_direction.size()]
        else:
            sprite = frames_for_direction[0]

    if sprite != null:
        # Os quadros têm uma faixa transparente na parte inferior.
        # Desenhamos apenas a área útil para alinhar os pés com a sombra.
        var source_rect := Rect2(0, 0, float(sprite.get_width()), minf(141.0, float(sprite.get_height())))
        var draw_size := Vector2(50, 62)
        var draw_rect := Rect2(Vector2(p.x - draw_size.x * 0.5, p.y - draw_size.y), draw_size)
        draw_texture_rect_region(sprite, draw_rect, source_rect, Color.WHITE, false, true)

    # Sombra imediatamente abaixo dos pés, não abaixo do retângulo transparente.
    _draw_ellipse(p + Vector2(0, 1), Vector2(9, 3), Color(0, 0, 0, 0.28))


func _draw_henrique(p: Vector2) -> void:
    if henrique_sprite_texture != null:
        var target_size := Vector2(50, 62)
        draw_texture_rect(henrique_sprite_texture, Rect2(p.x - target_size.x * 0.5, p.y - target_size.y, target_size.x, target_size.y), false)
    _draw_ellipse(p + Vector2(0, 1), Vector2(10, 3), Color(0, 0, 0, 0.28))


func _draw_ellipse(center: Vector2, radii: Vector2, color: Color) -> void:
    # Sombra oval pixelada feita com retângulos, compatível com Godot 4.7.
    draw_rect(Rect2(center.x - radii.x + 3, center.y - radii.y, (radii.x - 3) * 2, radii.y * 2), color)
    draw_rect(Rect2(center.x - radii.x, center.y - radii.y + 2, radii.x * 2, (radii.y - 2) * 2), color)
